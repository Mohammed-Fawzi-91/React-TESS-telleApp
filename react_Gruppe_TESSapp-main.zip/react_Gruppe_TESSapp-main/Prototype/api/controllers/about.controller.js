
const aboutUs = (req, res) =>{
    res.status(200).send('Vi lager ting')
    
}

module.exports = aboutUs