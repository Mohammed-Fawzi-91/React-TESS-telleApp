
const getTellelister = (req, res) =>{
    res.status(200).send('Her kan håndtere tellelister')
    
}

module.exports = getTellelister