const ressurser = (req, res) =>{
    res.status(200).send('Her kommer ulike ressurser tilknyttet varetelling i TESS')
  
}

module.exports = ressurser