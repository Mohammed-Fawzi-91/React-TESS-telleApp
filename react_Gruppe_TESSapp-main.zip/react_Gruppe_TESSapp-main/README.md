# APP2000 - Gruppe01 - TESSAPP
Prosjektoppgave i Applikasjonsutvikling.
- Semester: høst 2022 - vår 2023
- Gruppe: 1
- Oppgave: Håndterminal Logistikk/Varetelling App for TESS AS
