const dataSchema = require("../models/data");
const mongoose = require("mongoose");
const theData = mongoose.model("File", dataSchema);
/*weufhwefiwefi*//*weufhwefiwefi*/

const addData = (req, res) => {
  const file = req.file.buffer.toString();
  let data;
  if (req.file.originalname.endsWith(".csv")) {
    data = file
      .split("\n")
      .filter(Boolean)
      .map((line) => line.split(","))
      .map(([name, number, count]) => ({
        name,
        number,
        count,
      }));
  } else if (req.file.originalname.endsWith(".txt")) {
    data = file
      .split("\n")
      .filter(Boolean)
      .map((line) => line.split(/;{1,2}/).filter(Boolean))
      .map(([one, two, three]) => ({
        one,
        two,
        three,
      }));
  } else if (req.file.originalname.endsWith(".txt.ok")) {
    data = file
      .split("\n")
      .filter(Boolean)
      .map((line) => line.split(/;{1,2}/).filter(Boolean))
      .map(([name, number, count, kid, explanation]) => ({
        name,
        number,
        count,
        kid,
        explanation,
      }));
  }
  theData.insertMany(data, (error) => {
    if (error) {
      console.log(error);
      res.status(500).send(error);
    } else {
      res.send("Data uploaded and stored in MongoDB");
    }
  });
};

exports.addData = addData;
