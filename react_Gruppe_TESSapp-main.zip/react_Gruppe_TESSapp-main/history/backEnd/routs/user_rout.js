const express = require("express");
const multer = require("multer");
const storage = multer.memoryStorage();
const router = express.Router();
const upload = multer({ storage });
const {
  postUser,
  gettUser,
  logIn,
  veryFeidToken,
} = require("../control/User_Control");
const { addData } = require("../control/data_control");

router.post("/signup", postUser);
router.get("/getUser", gettUser);
router.post("/login", logIn);
router.post("/add", upload.single("file"), addData);
router.get("/user", veryFeidToken, gettUser);

module.exports = router;
