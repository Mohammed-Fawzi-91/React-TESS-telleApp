const express = require('express')
const router = express.Router()

const {
    getAllTerminals,
    getTerminal,
    addTerminals,
    updateTerminals,
    deleteTerminals,
} = require('../controllers/terminals.controller')

router.get('/', getAllTerminals)

router.get('/:id', getTerminal)

router.post('/', addTerminals)

router.patch('/:id', updateTerminals)

router.delete('/:id', deleteTerminals)

module.exports = router