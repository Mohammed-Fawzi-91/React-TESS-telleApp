const express = require('express')
const router = express.Router()

const {
    getAllOrders,
    getOrderByID,
    addOrder,
    updateOrder,
    deleteOrder
}
 = require('../controllers/orders.controller')

router.get('/', getAllOrders)
router.get('/:id', getOrderByID )
router.post('/', addOrder)
router.patch('/:id', updateOrder)
router.delete('/:id', deleteOrder)


module.exports = router