const taskIDDOM = document.querySelector('.task-edit-id')
const taskNameDOM = document.querySelector('.task-edit-name')
const taskLocationDOM = document.querySelector('.task-edit-location')
const taskCompletedDOM = document.querySelector('.task-edit-completed')
const editFormDOM = document.querySelector('.single-task-form')
const editBtnDOM = document.querySelector('.task-edit-btn')
const formAlertDOM = document.querySelector('.form-alert')
const params = window.location.search
const id = new URLSearchParams(params).get('id')
let tempName

const showTask = async () => {
  try {
    const {
      data: { terminal },
    } = await axios.get(`/api/v1/terminals/${id}`)
    const { _id: terminalID, available, name, location } = terminal

    taskIDDOM.textContent = terminalID
    taskNameDOM.value = name
    taskLocationDOM.value = location
    tempName = name
    if (available) {
      taskCompletedDOM.checked = true
    }
  } catch (error) {
    console.log(error)
  }
}

showTask()

editFormDOM.addEventListener('submit', async (e) => {
  editBtnDOM.textContent = 'Loading...'
  e.preventDefault()
  try {
    const terminalName = taskNameDOM.value
    const terminalLocation = taskLocationDOM.value
    const terminalAvailable = taskCompletedDOM.checked

    const {
      data: { terminal },
    } = await axios.patch(`/api/v1/terminals/${id}`, {
      name: terminalName,
      location: terminalLocation,
      available: terminalAvailable,
    })

    const { _id: terminalID, available, name } = terminal

    taskIDDOM.textContent = terminalID
    taskNameDOM.value = name
    tempName = name
    if (available) {
      taskCompletedDOM.checked = true
    }
    formAlertDOM.style.display = 'block'
    formAlertDOM.textContent = `success, edited terminal`
    formAlertDOM.classList.add('text-success')
  } catch (error) {
    console.error(error)
    taskNameDOM.value = tempName
    formAlertDOM.style.display = 'block'
    formAlertDOM.innerHTML = `error, please try again`
  }
  editBtnDOM.textContent = 'Edit'
  setTimeout(() => {
    formAlertDOM.style.display = 'none'
    formAlertDOM.classList.remove('text-success')
  }, 3000)
}) 
 