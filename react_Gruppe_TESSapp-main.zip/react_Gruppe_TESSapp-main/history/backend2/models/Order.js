const mongoose = require('mongoose')

const OrderSchema = new mongoose.Schema({
  
    amount: {
        type: Number,
        required:[true, 'must provide number of terminals'],
        trim: true,

    },

    requestDate: {
        type: Date,
        default: new Date(),
    },

    startDate: {
        type: Date,
        default: new Date(),
    },

    endDate: {
        type: Date,
        default: new Date() /* + (7*24*60*60*1000), */
    },

    requestedBy:{
        type: String,
        default: 'Drammen',
    },
})

module.exports = mongoose.model('Order', OrderSchema)