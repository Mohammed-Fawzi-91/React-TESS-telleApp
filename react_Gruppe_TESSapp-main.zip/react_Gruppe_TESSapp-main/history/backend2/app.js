//Built-in moduer
require('./db/connect')
const express = require('express')
const app = express()
//Connection-modul
const connectDB = require('./db/connect')
require('dotenv').config()
const path = require('path')
const cors = require('cors')



//Egenlagde moduler
const terminalsRouter = require('./routes/terminals.route')
const authRouter = require('./routes/auth.route')
const aboutRouter = require('./routes/about.route')
const ressursRouter = require('./routes/ressurs.route')
const ordersRouter = require('./routes/orders.route')
const tellelisteRouter = require('./routes/tellelister.route')

//Setter dir for static-folder, denne tillater for at express og react kan 
//lytte på samme port "samtidig". trenger kun å kjøre react appen
//gjør at cors (cross origin rerourses ikke er nødvendig å bruke)


/* app.use(express.static(path.join(__dirname, 'build'))) */

//Begge er ikke nødvendige?
/* app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'build', 'index.html'))
}); */

/* app.get('/*', function (req, res){
    res.sendFile(path.join(__dirname, 'build', 'index.html'))
}) */

app.use(cors()) 

app.set(express.static(path.join(__dirname, 'public')))

/* app.use(express.static('./public')) */


app.use(express.json())
//parse form data, for å få tak i data som legges inn i form
//app.use(express.urlencoded({ extended: false }))

//For håndtering av terminaler (admin)
app.use('/api/v1/terminals', terminalsRouter)

//For bestilling av terminaler
app.use('/api/v1/orders', ordersRouter)

//For håndtering a tellelister (.txt til JSON parse)
app.use('/api/v1/tellelister', tellelisteRouter)

//For log-in
app.use('/api/v1/login', authRouter)

//About us side
app.use('/api/v1/about', aboutRouter)

//For dokumenter/ressurser til varetelling
app.use('/api/v1/ressurser', ressursRouter)



//generell håndtering av alle URL-requester som ikke spesifikt håndteres 
/* app.use('*', (req, res)=>{
    res.writeHead(200, { 'content-type': 'text/html' })
    res.write('404 Page not found <br> <a href="https://www.google.com">Tilbake til starsiden</a> ')
    res.end()
}) */

const port = process.env.PORT || 9000

const start = async () =>{
    try{
        await connectDB(process.env.MONGO_URI)
        app.listen(port, console.log(`server is listening on port ${port}...`))
    }catch(error){
        console.log(error)
    }
}

start()