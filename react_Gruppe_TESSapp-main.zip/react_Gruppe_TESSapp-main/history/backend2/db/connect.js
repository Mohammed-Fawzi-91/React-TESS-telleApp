const mongoose = require('mongoose')

// Set `strictQuery` to `false`, so Mongoose doesn't strip out non-schema
// query filter properties by default.
// This does **not** affect `strict`.
mongoose.set('strictQuery', false)

const connectDB = (url) =>{
return mongoose.connect(url, {
    useNewUrlParser:true, 
    useUnifiedTopology: true,
    //useFindAndModify: false
})
}

module.exports = connectDB