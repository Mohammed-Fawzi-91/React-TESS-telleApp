const Order = require('../models/Order')

const getAllOrders = async (req, res) =>{
    try{
        const orders = await Order.find({})
        res.status(200).json({orders})
    } catch(error){
        res.status(500).json({ msg: error}) //500 = general server error
    }
}

const getOrderByID = async (req, res) =>{
    try{
        const{id:orderID} = req.params
        const order = await Order.findOne( { _id:orderID} )
    if(!order){
        return res.status(404).json({ msg: `No order with id: ${orderID}`} )
    }
    res.status(200).json({order})
    } catch (error){
        res.status(500).json({ msg: error})
    }   
}


const addOrder = async (req, res) =>{
    try{
        const order = await Order.create(req.body)
        res.status(201).json({order})
    } catch (error){
        res.status(500).json({msg: error})
    }
}

const updateOrder = async (req, res) =>{
    try{
        const { id:orderID } = req.params
        const order = await Order.findOneAndUpdate({ _id:orderID}, req.body,{
            new:true,
            runValidators:true,
        })
        if(!order){
            return res.status(404).json({ msg: `No terminal with id: ${orderID}`} )
        }
        res.status(200).json({ order })
    } catch (error) {
        res.status(500).json({msg: error})
    }
      
}

const deleteOrder = async (req, res) =>{
    try{
        const {id:orderID} = req.params
        const order = await Order.findOneAndDelete({_id:orderID})
        if(!order){
            return res.status(404).json({ msg: `No terminal with id: ${orderID}`} ) 
        }
        res.status(200).json({ order })
    }catch(error){
        res.status(500).json({msg: error})
    }
}

/* const addOrder = (req, res) =>{
    const {id, lagerNavn} = req.body
    console.log(req.params.id)
    //Leter etter terminal basert på request.parameter.id
    const terminal = terminals.find((terminal) => terminal.id === Number(req.params.id))
    //Sjekker om id og lagerNavn er lagt inn i body og om id i request.param
    //matcher med eksisterende terminalID. Tester også om id i body og request.param
    //matcher
    if(!id || !lagerNavn || (id !== Number(req.params.id)) || !terminal ){
        return res.status(400).json({success: false,
            //feilmeldingen må endres. En feilmelding for bruker
            //en annen for utvikler
             msg: 'Bestilling må ha gyldig lager og terminal ID'}) 
    }
    
    return res.status(200).json({success: true, msg:
         `Bestilling velykket for terminal med ID: ${id} for lager med ID: ${lagerNavn}`})
} */

module.exports = {
    getAllOrders,
    getOrderByID,
    addOrder,
    updateOrder,
    deleteOrder
}
