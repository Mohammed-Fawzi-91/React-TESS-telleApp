import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Dokumentasjon (){
    return(
        <div>
            <h1>Dokumentasjon</h1>
        </div>
    )
}

export default A_Dokumentasjon;