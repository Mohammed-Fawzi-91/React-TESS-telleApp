import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function B_Tellelister (){
    return(
        <React.Fragment>
            <div>
            <h1>Tellelister</h1>
        <hr/>
            </div>
        </React.Fragment>
       
    )
}

export default B_Tellelister;