import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function Footer (){
    return(
<div>
        <article class="">
            <h4>Footer</h4>
        </article>
       
</div>
    )
}

export default Footer;