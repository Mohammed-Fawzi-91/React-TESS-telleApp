import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Tellelister (){
    return(
        <div>
            <h1>Tellelister</h1>
        </div>
    )
}

export default A_Tellelister;