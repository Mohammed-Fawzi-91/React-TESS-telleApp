import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Inventar (){
    return(
        <div>
            <h1>Inventar</h1>

        </div>
    )
}

export default A_Inventar;