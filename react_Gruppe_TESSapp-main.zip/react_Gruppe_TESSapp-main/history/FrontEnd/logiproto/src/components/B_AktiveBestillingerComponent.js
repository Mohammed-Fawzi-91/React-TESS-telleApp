import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function B_AktiveBestillinger (){
    return(
        <div>
            <h1>Aktive Bestillinger</h1>   
        </div>
    )
}

export default B_AktiveBestillinger;