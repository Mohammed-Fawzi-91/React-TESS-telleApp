import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function B_Veiledninger (){
    return(
        <div>
            <h1>Bestillinger</h1>
        <hr/>
        </div>
    )
}

export default B_Veiledninger;