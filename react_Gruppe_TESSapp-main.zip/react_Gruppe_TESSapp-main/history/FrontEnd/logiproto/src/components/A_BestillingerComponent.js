import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Bestillinger (){
    return(
        <div>
            <h1>Bestillinger</h1>       
        </div>
    )
}

export default A_Bestillinger;