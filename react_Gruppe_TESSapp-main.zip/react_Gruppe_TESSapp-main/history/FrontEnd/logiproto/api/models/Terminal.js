const mongoose = require('mongoose')

const TerminalSchema = new mongoose.Schema({
    id: {
        type:String,
        required:[true, 'must provide ID for terminal'],
        trim: true,
        maxlength: [10, 'id can not be longer than 10 characters']
    },
    available: {
        type: Boolean,
        default: false,
    }
})

module.exports = mongoose.model('Terminal', TerminalSchema)