const terminals = [
    { id: 1, name: 'wapman1' },
    { id: 2, name: 'wapman2' },
    { id: 3, name: 'wapman3' },
    { id: 4, name: 'wapman4' },
    { id: 5, name: 'wapman5' },
  ]

  const people = [
    {userName: "Kjell", password: "123"},
    {userName: "Vidar", password: "321"},
  ]
  module.exports =  { terminals, people }