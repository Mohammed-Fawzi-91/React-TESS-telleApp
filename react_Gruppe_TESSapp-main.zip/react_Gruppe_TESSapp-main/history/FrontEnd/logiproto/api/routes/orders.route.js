const express = require('express')
const router = express.Router()

const {
    getOrders,
    addOrder,
}
 = require('../controllers/orders.controller')

router.get('/', getOrders)
router.post('/:id', addOrder )

module.exports = router