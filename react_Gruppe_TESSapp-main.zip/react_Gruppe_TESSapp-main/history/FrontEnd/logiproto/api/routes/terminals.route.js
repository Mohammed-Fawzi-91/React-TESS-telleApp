const express = require('express')
const router = express.Router()

const {
    getAllTerminals,
    addTerminals,
    updateTerminals,
    deleteTerminals,
} = require('../controllers/terminals.controller')

router.get('/', getAllTerminals)

router.post('/', addTerminals)

router.put('/:id', updateTerminals)

router.delete('/:id', deleteTerminals)

module.exports = router