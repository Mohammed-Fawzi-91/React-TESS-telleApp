let { people } = require ('../data')

const logIn = (req, res) =>{
    const { name } = req.body
    if(name){
        return res.status(200).send(`Velkommen ${name}`)
    }
    res.status(401).send('Feil brukernavn eller passord')
    
}

module.exports = logIn