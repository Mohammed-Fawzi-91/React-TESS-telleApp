let { terminals } = require('../data')

const getOrders = (req, res) =>{
    res.status(200).send('Her kan du bestille terminaler')
    
}

const addOrder = (req, res) =>{
    const {id, lagerNavn} = req.body
    console.log(req.params.id)
    //Leter etter terminal basert på request.parameter.id
    const terminal = terminals.find((terminal) => terminal.id === Number(req.params.id))
    //Sjekker om id og lagerNavn er lagt inn i body og om id i request.param
    //matcher med eksisterende terminalID. Tester også om id i body og request.param
    //matcher
    if(!id || !lagerNavn || (id !== Number(req.params.id)) || !terminal ){
        return res.status(400).json({success: false,
            //feilmeldingen må endres. En feilmelding for bruker
            //en annen for utvikler
             msg: 'Bestilling må ha gyldig lager og terminal ID'}) 
    }
    
    return res.status(200).json({success: true, msg:
         `Bestilling velykket for terminal med ID: ${id} for lager med ID: ${lagerNavn}`})
}

module.exports = {
    getOrders,
    addOrder,
}
