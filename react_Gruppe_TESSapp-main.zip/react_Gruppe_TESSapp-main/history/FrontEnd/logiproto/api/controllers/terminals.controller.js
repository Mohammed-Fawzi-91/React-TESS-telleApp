let { terminals } = require('../data')
const Terminal = require('../models/Terminal')

const getAllTerminals = async (req, res) =>{
    try{
        const terminal = await Terminal.find({})
        res.status(200).json({terminal})
    } catch(error){
        res.status(500).json({ msg: error}) //500 = general server error
    }
}

const addTerminals = async (req, res) =>{
    try{
        const terminal = await Terminal.create(req.body)
        res.status(201).json({terminal})
    } catch (error){
        res.status(500).json({msg: error})
    }
}

const updateTerminals = (req, res) =>{
    const { id } = req.params
    const { name } = req.body
    console.log(req.params)
    console.log(req.body)

    const terminal = terminals.find((terminal) => terminal.id === Number(id)) 

    if(!terminal){
        return res
        .status(404)
        .json({ success: false, msg: `Finner ikke terminal med id ${id}` })
    }

    const newTerminal = terminals.map((terminal) => {
        if(terminal.id === Number(id)){
            terminal.name = name
        }
        return terminal
    })
    res.status(200).json({ success: true, data: newTerminal})
}

const deleteTerminals = (req, res) =>{
    const terminal = terminals.find((terminal) => terminal.id === Number(req.params.id))
    if(!terminal){
        return res
        .status(404)
        .json({ success: false, msg:`Ingen terminal med id ${req.params.id}`})
    }
    const newTerminal = terminals.filter(
        (terminal) => terminal.id !== Number(req.params.id))
    return res.status(200).json({success:true, data: newTerminal})
}

module.exports = {
    getAllTerminals,
    addTerminals,
    updateTerminals,
    deleteTerminals,
}
  