//Import IF == Admin Else Import Bruker?
import React from 'react'

//ADMIN SIDER
import A_Bestillinger from './A_BestillingerComponent';
import A_Brukere from './A_BrukereComponent';
import A_Dokumentasjon from './A_DokumentasjonComponent';
import A_Header from './A_HeaderComponent';
import A_Inventar from './A_InventarComponent';
import A_Tellelister from './A_TellelisterComponent';

//GENERISKE SIDER
import Footer from './FooterComponent';
import OmOss from './OmOssComponent';

import {Switch, Route, Redirect, withRouter, BrowserRouter} from 'react-router-dom';

//TODO: Opprette en variabel for å tilknytte brukerID, deretter skiftes ruting til enten B_ eller A_ Header
//Også en mulighet å lage 2 main funksjoner her og sette spørringen i App.js
//TODO: Variabel tilknyttet Redirect
function MainAdmin (){
        return(
            <React.Fragment>
                <div>HELLO WORLD FRA ADMINMAIN</div>
        <A_Header/> 
        <BrowserRouter>
        <Switch>
            <Route path='/A_Inventar' component={A_Inventar}/>
            <Route path='/A_Bestillinger' component={A_Bestillinger}/>
            <Route path='/A_Tellelister' component={A_Tellelister}/>
            <Route path='/A_Dokumentasjon' component={A_Dokumentasjon}/>
            <Route path='/A_Brukere' component={A_Brukere}/>
            <Route path='/OmOss' component={OmOss}/>

            <Redirect to="/B_Bestill"/> 
        </Switch>
        </BrowserRouter>
               
        <Footer/>
            </React.Fragment>
        )
}

export default withRouter(MainAdmin);

/*
Inventar
Bestillinger
Tellelister
Dokumentasjon
Brukere
OmOss
*/