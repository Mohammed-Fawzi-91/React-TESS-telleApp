import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Inventar (){
    return(
        <div>Hello World fra Admin A_Inventar</div>
    )
}

export default A_Inventar;