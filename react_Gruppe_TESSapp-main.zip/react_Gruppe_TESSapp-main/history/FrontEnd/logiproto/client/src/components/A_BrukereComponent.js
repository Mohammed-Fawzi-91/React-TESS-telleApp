import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Brukere (){
    return(
        <div>Hello World fra Admin Brukerside</div>
    )
}

export default A_Brukere;