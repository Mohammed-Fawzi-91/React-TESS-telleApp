import React from "react"
import {Link} from 'react-router-dom'
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Header (){
    return( 
        <div>
            <div class="banner">
            <div class="user-button">
                <button class="button">user:loc<span>Log Out</span></button>
                <button class="button"><span>user:loc</span></button>
                <div class="user-dropdown">
                    <button class="button"><span>Logg ut</span></button>
                </div>
            </div>
            <button class="button"><span><Link to='/A_Inventar'onClick={() => {window.location.href='/A_Inventar'}}>Inventar</Link></span></button>
            <button class="button"><span><Link to='/A_Bestillinger'onClick={() => {window.location.href='/A_Bestillinger'}}>Aktive Bestillinger</Link></span></button>
            <button class="button"><span><Link to='/A_Tellelister'onClick={() => {window.location.href='/A_Tellelister'}}>Tellelister</Link></span></button>
            <button class="button"><span><Link to='/A_Dokumentasjon'onClick={() => {window.location.href='/A_Dokumentasjon'}}>Dokumentasjon</Link></span></button>
            <button class="button"><span><Link to='/OmOss'onClick={() => {window.location.href='/OmOss'}}>Om Oss</Link></span></button>
        </div>
    
    
        </div>
        )
}

export default A_Header;

/*
Inventar
Bestillinger
Tellelister
Dokumentasjon
Brukere
OmOss
*/