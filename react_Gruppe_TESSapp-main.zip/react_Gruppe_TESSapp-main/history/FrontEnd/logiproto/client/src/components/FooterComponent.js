import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function Footer (){
    return(
        <div>Hello World fra Footer</div>
    )
}

export default Footer;