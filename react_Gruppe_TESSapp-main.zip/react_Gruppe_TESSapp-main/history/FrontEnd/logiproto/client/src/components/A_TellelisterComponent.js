import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Tellelister (){
    return(
        <div>Hello World fra Admin A_Tellelister</div>
    )
}

export default A_Tellelister;