import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Bestillinger (){
    return(
        <div>Hello World fra Admin Bestillinger</div>
    )
}

export default A_Bestillinger;