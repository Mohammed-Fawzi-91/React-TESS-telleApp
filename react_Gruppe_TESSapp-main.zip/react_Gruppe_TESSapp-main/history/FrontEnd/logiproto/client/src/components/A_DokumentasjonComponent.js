import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function A_Dokumentasjon (){
    return(
        <div>Hello World fra Admin Dokumentasjon</div>
    )
}

export default A_Dokumentasjon;