import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function B_Tellelister (){
    return(
        <React.Fragment>
            <div>Hello World fra Bruker B_Tellelister</div>
        </React.Fragment>
       
    )
}

export default B_Tellelister;