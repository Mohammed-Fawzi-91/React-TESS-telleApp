import React from "react"
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function B_AktiveBestillinger (){
    return(
        <div>Hello World fra Bruker b_AktiveBestillinger</div>
    )
}

export default B_AktiveBestillinger;