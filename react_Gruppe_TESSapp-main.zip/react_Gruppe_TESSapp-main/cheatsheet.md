# CHEAT SHEET
Satt sammen et lite cheat sheet for ikke å glemme nyttige og relevante ting som steg, kommandoer, osv.

---

## INNHOLDSLISTE
- [MongoDB Database Tools](#mongodb-database-tools)
  - [Operasjoner](#database-tools-operasjoner)
  - [GridFS](#gridfs)

---

### MongoDB Database Tools
Må brukes dersom man vil kunne sette hele dokumenter (binærfiler) inn i databasen(e).

Lenke til nedlastning av verktøyet og full manual finner man [her](https://www.mongodb.com/docs/database-tools/).

Man må lage to collections under databasen for å kunne laste opp filer/objekter:
  - `fs.chunks`: her lever selve innholdet i dokumentet.
  - `fs.files`: her lever metadataene til dokumentet.

#### Database Tools: Operasjoner
##### mongofiles
```
get    # laster ned filen
put    # laster opp filen

list   # lister opp alle filene 
search # leter etter filer

delete # selvforklarende
```
Det finnes sikkert mer man kan gjøre, men dette er det som er relevant til vårt bruk.

Eksempel på filopplasting:
```
mongofiles --uri 'mongodb+srv://BRUKERNAVN:PASSORD@tessapp.arm1gix.mongodb.net/?retryWrites=true&w=majority' --db=pdf put DOKUMENTNAVN.EXTENSION
```

#### GridFS
GridFS er et verktøy som MongoDB tilbyr for lagring og gjenoppretting av store filer, som bilder, lydfiler eller video. GridFS er nyttig når du trenger å lagre filer som overskrider MongoDBs maksimale BSON-dokumentstørrelse på 16MB.

Dokumentasjonen på GridFS finner man [her](https://www.mongodb.com/docs/manual/core/gridfs/).

---